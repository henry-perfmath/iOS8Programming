//
//  main.swift
//  MoreAdvancedSwift
//
//  Created by Henry Liu on 9/19/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation
/*
// trailing closure example
let directions = ["E": "East", "W": "West", "N": "North", "S": "South"]
let combos = ["NE", "SW", "NNE", "SSW"]

let mappedCombos = combos.map {
    (var combo) -> String in
    var output = ""
    for character in combo {
        println (character)
        var key = String(character)
        output += directions [key]!
    }
    return output
}
println (mappedCombos)
*/
/*
// capturing value example
func stringAppender (forAppend char: Character) -> () -> String {
    var runningString = "xyz"
    func appender () -> String {
        runningString += char
        println ("runnigString: \(runningString)")
        return runningString
    }
    return appender
}

let appendA = stringAppender (forAppend: "a")
appendA ()
appendA ()
//println (appendA)
let appendB = stringAppender (forAppend: "b")
appendB ()
//println (appendB)
appendA ()
appendB ()
//println (appendA)
*/
/*
// matrix subscripting example
struct Matrix {
    let rows: Int, columns: Int
    var grid: [Double]
    init (rows: Int, columns: Int) {
        self.rows = rows
        self.columns = columns
        grid = Array (count: rows * columns, repeatedValue: 0.0)
    }
    func indexIsValid (row: Int, column: Int) -> Bool {
        return row >= 0 && row < rows && column >= 0 && column < columns
    }
    subscript (row: Int, column: Int) -> Double {
        get {
            assert (indexIsValid(row, column: column), "index out of range")
            return grid [(row * column) + column]
        }
        set {
            assert (indexIsValid(row, column: column), "index out of range")
            grid [(row * column) + column] = newValue
        }
    }
}
var matrix = Matrix (rows: 2, columns: 2)

println (matrix [1, 1])
matrix [1, 1] = 9.99
println (matrix [1,1])

for row in 0 ..< matrix.rows {
    for column in 0 ..< matrix.columns {
        println ("row = \(row) column = \(column): \(matrix[row, column])")
    }
}
println (matrix)
*/
/*
// optional chaining example #1
class Customer {
    var account: Account?
}
class Account {
    var balance: Double = 0.0
}

let customer = Customer ()
//customer.account = Account ()
println (customer.account!.balance)
//println (customer.account?.balance)

if let accountBalance = customer.account?.balance {
    println ("customer's balance is \(accountBalance)")
} else {
    println ("unable to retrieve customer's balance")
}
*/

// optional chaining example #2
class Customer {
    var account: Account?
}
class Holder {
    let name:String
    init (name: String) {self.name = name}
}
class Address {
    var streetNumber: String?
    var streetName: String?
    var apartmentNumber: String?
    var city: String?
    var state: String?
    var zipCode: String?
    func addressIdentifier () -> String? {
        var id: String?
        if apartmentNumber != nil {
            id = apartmentNumber!
        }
        if streetNumber != nil && streetName != nil && city != nil {
            id = id! + String (format: streetNumber! + " " + streetName! + ", " + city!)
        } else {
            id = nil
        }
        return id
    }
}
class Account {
    var balance: Double = 0.0
    var holders = [Holder] ()
    var numberOfHolders: Int {
        return holders.count
    }
    subscript (i: Int) -> Holder {
        get {
            return holders [i]
        }
        set {
            holders [i] = newValue
        }
    }
    func printNumberOfHolders () {
        println ("# of holders for this account: \(numberOfHolders)")
    }
    var address: Address?
}

let customer = Customer ()
customer.account = Account ()

let holder1 = Holder (name: "Primary")
let holder2 = Holder (name: "Secondary")

customer.account?.holders.append(holder1)
customer.account?.holders.append(holder2)

// accessing properties through optional chaining
if let numberOfHolders = customer.account?.numberOfHolders {
    println ("number of account holders = \(numberOfHolders)")
} else {
    println ("unable to retrieve number of account holders")
}

let address = Address ()
address.apartmentNumber = ""
address.streetNumber = "123"
address.streetName = "One Way"
address.city = "Any City"

customer.account?.address = address
println (customer.account?.address?.addressIdentifier())

// calling method through optional chaining
if customer.account?.printNumberOfHolders() != nil {
    println("The preceding line is from  calling the method printNumberOfHolders ()")
} else {
    println("It was not possible to print the number of holders.")
}

if (customer.account?.address = address) != nil {
    println("set address for customer's account succeeded.")
} else {
    println("It was not possible to set the address for the customer's account")
}

// accessing subscripts through optional chaining
if let firstHolderName = customer.account?[0].name {
    println("The first holder name is \(firstHolderName).")
} else {
    println("Unable to retrieve the first holder name.")
}

if let firstHolderName = customer.account?.holders[1].name {
    println("The second holder name is \(firstHolderName).")
} else {
    println("Unable to retrieve the first second name.")
}

customer.account?[1] = Holder (name: "Spouse")
if let firstHolderName = customer.account?.holders[1].name {
    println("The second holder name is \(firstHolderName).")
} else {
    println("Unable to retrieve the first second name.")
}

// accessing subscripts of optional type
var creditScores = ["Customer1": [840, 835, 839], "Customer2": [700, 710, 699]]
println (creditScores)
creditScores["Customer1"]?[1] = 825
creditScores["Customer2"]?[2] = 725
println (creditScores)

// multilevel chaining
if let streetName = customer.account?.address?.streetName? {
    println("Customer's street name is \(streetName).")
} else {
    println("Unable to retrieve the address.")
}

// chaining on methods with optional return values
if let addressIdentifier = customer.account?.address?.addressIdentifier() {
    println("customer's address identifier is \(addressIdentifier).")
}
if let addressIdentifierIsEmpty = customer.account?.address?.addressIdentifier()?.isEmpty {
    if (addressIdentifierIsEmpty) {
        println("customer's address identifier is empty.")
    } else {
        println("customer has a non-empty address identifier.")
    }
}

//// Generics examples
// generic function example
func swapTwoValues<T>(inout a: T, inout b: T) {
    let temp = a
    a = b
    b = temp
}

var i1 = 3
var i2 = 5
swapTwoValues (&i1, &i2)
println ("i1 = \(i1) i2 = \(i2)")

var str1 = "Left"
var str2 = "Right"
swapTwoValues (&str1, &str2)
println ("str1 = \(str1) str2 = \(str2)")

// generic type example
struct Stack<T> {
    var elements = [T] ()
    mutating func push (element: T) {
        elements.append(element)
    }
    mutating func pop () -> T {
        return elements.removeLast()
    }
}

var stack = Stack<String> ()
stack.push ("This")
stack.push ("is")
stack.push ("a")
stack.push ("test!")

let lastElement = stack.pop()
println ("last element of the stack: \(lastElement)")