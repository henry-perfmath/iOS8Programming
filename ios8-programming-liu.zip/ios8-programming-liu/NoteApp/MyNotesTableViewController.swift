//
//  MyNotesTableViewController.swift
//  NoteApp
//
//  Created by Henry Liu on 8/25/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation
import UIKit

class MyNotesTableViewController: UITableViewController, UITableViewDelegate, UITableViewDataSource {
    var noteItems = [AnyObject] ()

    @IBAction func unwindToList (segue: UIStoryboardSegue) {
        var source: AddNewNoteItemViewController = segue.sourceViewController as AddNewNoteItemViewController
        if let item = source.noteItem as NoteItem! {
            self.noteItems.append(item)
            self.tableView.reloadData()
        }
        /*
        var item: NoteItem = source.noteItem!
        if item != nil {
            self.noteItems.append(item)
            self.tableView.reloadData()
        }
        */
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        loadInitialData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    // not needed anymore in iOS 8
    func numberOfRowsInSelection (tableView: UITableView) -> Int {
       return noteItems.count
    }
    func loadInitialData () {
        let item1: NoteItem = NoteItem (name: "Apple ID", isCompleted: false)
        let item2: NoteItem = NoteItem (name: "Golden 1", isCompleted: false)
        let item3: NoteItem = NoteItem (name: "citi MC", isCompleted: false)
        
        noteItems.append(item1)
        noteItems.append(item2)
        noteItems.append(item3)
        
    }
    override func tableView (tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let listPropertyCell: String = "ListPrototypeCell"
        var cell: UITableViewCell = self.tableView.dequeueReusableCellWithIdentifier(listPropertyCell, forIndexPath: indexPath) as UITableViewCell
        var noteItem: NoteItem = noteItems [indexPath.row] as NoteItem
        cell.textLabel?.text = noteItem.itemName
        
        if noteItem.completed {
            cell.accessoryType = UITableViewCellAccessoryType.Checkmark
            noteItem.markAsCompleted (true)
            //noteItem.setCompletionDate(onDate: NSDate ())
        } else {
            cell.accessoryType = UITableViewCellAccessoryType.None
        }
        return cell
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return self.noteItems.count
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        println ("didSelectRowAtIndexPath: \(indexPath.row)")
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        let tappedItem: NoteItem = noteItems [indexPath.row] as NoteItem
        tappedItem.completed = !tappedItem.completed
        //tableView.reloadData()
        tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
        //reloadInputViews()
    }
}