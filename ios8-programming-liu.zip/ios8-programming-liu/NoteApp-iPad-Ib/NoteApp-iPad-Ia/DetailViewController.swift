//
//  DetailViewController.swift
//  NoteApp-iPad-Ia
//
//  Created by Henry Liu on 8/28/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import UIKit
protocol DetailViewControllerDelegate {
    func saveItemRequest (itemToSave: AnyObject)
}
//@class DetailViewController
    
class DetailViewController: UIViewController {
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    var delegate: DetailViewControllerDelegate!
    
    @IBAction func saveData(sender: AnyObject) {
        println ("DVC: saveData +")
        var item = NoteItem ()
        item.itemName = textField.text
        item.content = textView.text
        if delegate != nil {
            self.delegate?.saveItemRequest(item)
    
        } else {
            println ("delegate is nil in DVC")
        }
        println ("DVC: saveData -")
    }
    var detailItem: AnyObject? {
        didSet {
            
            println ("DVC: detailItem didSet +")
            // Update the view.
            self.configureView()
            println ("DVC: detailItem didSet -")
        }
    }

    func configureView() {
        println ("DVC: configureView +")
        // Update the user interface for the detail item.
        
        if let detail: AnyObject = self.detailItem {
            if let dI0 = detail as? Detail {
            self.delegate = dI0.delegate

            if let tv = textField {
                let item = dI0.noteItem as NoteItem
                self.textField.text = item.itemName as String
                self.textView.text = item.content as String
                
                println ("DVC: textField is \(self.textField.text)")
            } else {
                println ("textField is nil")
            }
            } else {
                println ("DVC: DI0 nil")
            }
        }
        println ("DVC: configureView -")
    }

    override func viewDidLoad() {
        println ("DVC: viewDidLoad +")
        //println ("\n2: calling deatil view controller's view didLoad")
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // do not conigure view here. Do it in configureView method
        //let url = NSURL(string: "http//www.apple.com")
        //let request = NSURLRequest(URL: url)
        //webView.loadRequest(request)

        //self.textField.text = "test"
        //self.textView.text = "test"
        //if self.delegate != nil {
        //    self.delegate = MasterViewController ()
        //}
//        self.delegate = DetailViewController ()
        //self.currentRowIndex = -1
        //println ("viewDidLoad: calling configView ()")

        self.configureView()
        //println ("exiting detail view controller's view didLoad")
        println ("DVC: viewDidLoad -")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
/*
    override func splitViewController (splitController: UISplitViewController, willHideViewController viewController: UIViewController, withBarButtonItem barButtonItem: UIBarButtonItem, forPopoverController popoverController: UIPopoverController) {
        barButtonItem.title = NSLocalizedString ("My Favorite Websites")
        self.navigationItem.setLeftBarButtonItem(barButtonItem, animated: true)
    }
    func splitViewController (splitController: UISplitViewController, willShowViewController viewController: UIViewController, invalidatingBarButtonItem barButtonItem: UIBarButtonItem) {
        self.masterPopoverController = nil
    }
 */   
}

