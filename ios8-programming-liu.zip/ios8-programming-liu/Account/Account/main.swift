//
//  main.swift
//  Account
//
//  Created by Henry Liu on 8/19/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

//import Foundation
/*
var account1 = Account (freeChecking: 0.0)
println ("Account type: \(account1.accountType) with monthly service fee: \(account1.monthlyServiceFee)")

var account2 = Account (premiumChecking: 5.0)
println ("Account type: \(account2.accountType) with monthly service fee: \(account2.monthlyServiceFee)")


var savingsAccount = SavingsAccount ()
println ("interest rate: \(savingsAccount.interestRate)")

savingsAccount.interestRate = 0.002
println ("interest rate: \(savingsAccount.interestRate)")


let checkingAccount1 = CheckingAccount (depositFee: 1.0, withdrawFee: 2.0)
println ("checking account 1: depositFee = \(checkingAccount1.depositFee) withdrawFee = \(checkingAccount1.withdrawFee)")

let checkingAccount2 = CheckingAccount (1.0)
println ("checking account 2: depositFee = \(checkingAccount2.depositFee) withdrawFee = \(checkingAccount2.withdrawFee)")



let xAccount = XAccount (12345678)
xAccount.showAccountInfo()

xAccount.deposit(100.0)
xAccount.showAccountInfo()

*/

let xAccount = XAccount (12345678)
xAccount.showAccountInfo()

xAccount.deposit (100.0, withdraw: 50.0)
xAccount.showAccountInfo()