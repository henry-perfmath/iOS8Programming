//
//  MyNotesTableViewController.swift
//  NoteApp
//
//  Created by Henry Liu on 8/25/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation
import UIKit
import CoreData

@objc (NoteItem1)
class NoteItem1: NSManagedObject {
    @NSManaged var itemName: String
}


class MyNotesTableViewController: UITableViewController, UITableViewDelegate, UITableViewDataSource {
    var noteItems = [AnyObject] ()
    var _dataFilePath = "/noteapp2_data.archive"

    @IBAction func unwindToList (segue: UIStoryboardSegue) {
        var source: AddNewNoteItemViewController = segue.sourceViewController as AddNewNoteItemViewController
        var item: NoteItem = source.noteItem!
        if let item = source.noteItem as NoteItem!  {
            self.noteItems.append(item)
            self.tableView.reloadData()
            saveData(item)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationItem.leftBarButtonItem = self.editButtonItem()
        loadInitialData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    // not needed anymore in iOS 8
    func numberOfRowsInSelection (tableView: UITableView) -> Int {
       return noteItems.count
    }
    func saveData (item: NoteItem) {
        println ("saving note using Core Data for \(item.itemName)")
        let  appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        let context: NSManagedObjectContext = appDelegate.managedObjectContext!
        let noteEntity = NSEntityDescription.entityForName("Notes", inManagedObjectContext: context)
        
        // insert newNote into context
        var newNote = NoteItem1 (entity: noteEntity!, insertIntoManagedObjectContext: context)
        
        // bad -  crashes even w/o newNote.itemName = textView.text
        // var newNote = NSEntityDescription.insertNewObjectForEntityForName("MyNotes",inManagedObjectContext: context) as NoteItem
        
        //set note name (don't do newNote.itemName = textView.text - crashes)
        newNote.setValue(item.itemName, forKey: "note")
        var error: NSError?
        context.save(&error)
        println ("note \"\(item.itemName)\" saved")
    }
    
    func loadInitialData () {
        println ("loading initial data using Core Data ")
        let  appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        let context: NSManagedObjectContext = appDelegate.managedObjectContext!
        let noteEntity = NSEntityDescription.entityForName("Notes", inManagedObjectContext: context)
        
        //let searchString = textView.text
        // must include double quote escape
        var request: NSFetchRequest  = NSFetchRequest (entityName: "Notes")
        request.predicate = NSPredicate (format: "note != nil")
        
        var error: NSError?
        var objects = context.executeFetchRequest (request, error:&error)
        
        if objects?.count == 0 {
            println ("No data in the database")
        } else {
            for foundItem: NSManagedObject in objects as [NSManagedObject] {
                var itemName = foundItem.valueForKey("note") as String
                println ("found: \(itemName) of \(objects?.count)")
                noteItems.append(NoteItem (name: itemName))
            }
        }

    }
    override func tableView (tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let listPropertyCell: String = "ListPrototypeCell"
        var cell: UITableViewCell = self.tableView.dequeueReusableCellWithIdentifier(listPropertyCell, forIndexPath: indexPath) as UITableViewCell
        var noteItem: NoteItem = noteItems [indexPath.row] as NoteItem
        cell.textLabel?.text = noteItem.itemName
        
        if noteItem.completed {
            cell.accessoryType = UITableViewCellAccessoryType.Checkmark
            noteItem.setCompletionDate(onDate: NSDate ())
        } else {
            cell.accessoryType = UITableViewCellAccessoryType.None
        }
        return cell
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return self.noteItems.count
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        println ("didSelectRowAtIndexPath: \(indexPath.row)")
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        let tappedItem: NoteItem = noteItems [indexPath.row] as NoteItem
        tappedItem.completed = !tappedItem.completed
        //tableView.reloadData()
        tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
        //reloadInputViews()
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath)
    -> Bool {
    // Return NO if you do not want the specified item to be editable.
    return true;
    }
/*
    override func tableView(tableView: UITableView,  editStyleForRowAtIndexPath indexPath:NSIndexPath)
    -> UITableViewCellEditingStyle {
    //return UITableViewCellEditingStyleInsert; doesn't work
    return UITableViewCellEditingStyleDelete;
    }
*/

    // Override to support editing the table view.
    override func tableView (tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) 
    {
        if editingStyle == .Delete {
            
            // Delete the row from the data source
            // Get the managedObjectContext from the AppDelegate (for use in CoreData Applications)
            let appdelegate = UIApplication.sharedApplication().delegate as AppDelegate
            let context: NSManagedObjectContext = appdelegate.managedObjectContext!
            // Delete the row from the data source
    
            var item: NoteItem = noteItems[indexPath.row] as NoteItem
            self.noteItems.removeAtIndex (indexPath.row)
    
            // You might want to delete the object from your Data Store if you’re using CoreData
    
            var entityDesc: NSEntityDescription = NSEntityDescription.entityForName ("Notes", inManagedObjectContext:context)!
    
            var request: NSFetchRequest  = NSFetchRequest (entityName: "Notes")
            println ("fetch \(item.itemName)")
            request.predicate = NSPredicate (format: "note == \"\(item.itemName)\"")
    
            var error: NSError?
            var objects = context.executeFetchRequest (request, error:&error)
            context.deleteObject (objects?[0] as NSManagedObject)
    
            context.save (&error)

            // Animate the deletion
            tableView.deleteRowsAtIndexPaths ([indexPath], withRowAnimation: UITableViewRowAnimation.Fade)
        } else if editingStyle == .Insert {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }

    

    
    // Override to support rearranging the table view.
    override func tableView (tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath,  toIndexPath: NSIndexPath)
    {
    }
    
    
    
    // Override to support conditional rearranging of the table view.
    override func tableView (tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath)
    -> Bool {
    // Return false if you do not want the item to be re-orderable.
    return true;
    }
    

}