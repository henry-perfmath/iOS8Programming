//
//  main.swift
//  DataPersistence
//
//  Created by Henry Liu on 8/26/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation
var start = mach_absolute_time()
var currentDate = NSDate ()
println (currentDate)
//var dateFormatter = NSDateFormatter ()
//dateFormatter.dateStyle = .ShortStyle
//println (dateFormatter.stringFromDate (currentDate))

//dateFormatter.setDateFormat("yyyy-MM-dd' 'HH:mm:ss.SSS'Z'")
//var localDateString: String = dateFormatter.stringFromDate (currentDate)

// get file size
let fileName = "/Users/henry/mydev/workspace/ios8/DiskCheck/ioTest1.txt"
let bufferSize = 50000

var fileMgr = NSFileManager.defaultManager()
var attrs: NSDictionary  = fileMgr.attributesOfItemAtPath (fileName, error:nil)
let fileSize = attrs.fileSize()
println (fileSize)

var end = mach_absolute_time()
println ("elaped: \(end - start)")