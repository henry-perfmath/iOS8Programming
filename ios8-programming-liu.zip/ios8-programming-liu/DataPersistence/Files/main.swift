//
//  main.swift
//  Files
//
//  Created by Henry Liu on 8/26/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation


var start: clock_t
var end: clock_t

start = clock()

// 1. get the shared file manager object
var fileMgr: NSFileManager = NSFileManager.defaultManager()

//2. read data of a file in its entirety into an NSData object
var data: NSData = fileMgr.contentsAtPath("/Users/henry/mydev/workspace/ios8/DiskCheck/ioTest1.txt")

//3. write data of a file in its entirety to a file
fileMgr.createFileAtPath("/Users/henry/mydev/workspace/ios8/DiskCheck/ioTmp.txt", contents: data, attributes: nil)

end = clock()
//let CLOCKS_PER_SEC = 1000000.0
var elapsed: clock_t = (end - start) / 1000
println ("Time: \(elapsed) ms")

// 4. use NSFileHandle to read a file block by block
var file: NSFileHandle = NSFileHandle (forReadingAtPath:"/Users/henry/mydev/workspace/ios8/DiskCheck/ioTest1.txt")
if file == nil {
    println ("Cannot open file for read")
}

var bufferSize: Int = 513
//5. read the file with a fixed buffer size into an NSData object

var data2 = file.readDataOfLength(bufferSize)

// 6. copy data from an NSData object to a String object
var aStr: String = NSString (data: data2!, encoding: NSASCIIStringEncoding)
println (aStr)

//7. Tokenize the String line by libe into an array
var tokens = aStr.componentsSeparatedByString("\n")
let n = tokens.count

for (var i = 0; i < n; i++) {
    if i < 3 {
        println ("\(i): \(tokens[i])")
    }
}
println ("n = \(n)")

//8. close the file handle
file.closeFile()
