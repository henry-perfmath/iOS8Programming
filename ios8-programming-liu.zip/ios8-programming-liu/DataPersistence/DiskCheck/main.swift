//
//  main.swift
//  DiskCheck
//
//  Created by Henry Liu on 8/26/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation

func readWriteTest (#fileName: String, #bufferSize: Int) {
    println ("bufferSize: \(bufferSize)")
    // for calculating total execution time
    var start: UInt64 = 0
    var end: UInt64 = 0
    
    // use NSFileHandle to read a file
    var fileHandleIn = NSFileHandle (forReadingAtPath:fileName)

    if fileHandleIn == nil {
        println ("Cannot open file \(fileName) for read")
        exit (1)
    }
    
    // get file size

    var fileMgr = NSFileManager.defaultManager()
    var attrs: NSDictionary  = fileMgr.attributesOfItemAtPath (fileName, error:nil)
    let inputFileSize: UInt64 = attrs.fileSize()
    
    // construct output file handle
    var outFileName:  String = fileName + "_" + getFileNamePostFix()
    // must create the output file first
    fileMgr.createFileAtPath (outFileName, contents:nil, attributes:nil)
    
    var fileHandleOut = NSFileHandle (forUpdatingAtPath: outFileName)
    var outData: NSData? // for writeData
    
    //int bufferSize = 50000;
    var offset:UInt64 = 0
    
    var eof = false
    var startRead: UInt64 = 0
    var endRead: UInt64 = 0
    var totalReadTime: UInt64 = 0
    
    var startWrite: UInt64 = 0
    var endWrite: UInt64 = 0
    var totalWriteTime: UInt64 = 0
    var numOfLines = 0
    var writeOffset: UInt64 = 0
    
    var startConvert: UInt64 = 0
    var endConvert: UInt64 = 0
    var totalConvertTime: UInt64 = 0
    
    var startTokenizing: UInt64 = 0
    var endTokenizing: UInt64 = 0
    var totalTokenizingTime: UInt64 = 0
    
    start = mach_absolute_time()
    do {
        if offset < inputFileSize {

            //
            fileHandleIn.seekToFileOffset (offset)
            startRead = mach_absolute_time()
            var dataBuffer: NSData = fileHandleIn.readDataOfLength(bufferSize)
            endRead = mach_absolute_time()
            totalReadTime += endRead - startRead
            
            // convert NSData to String
            startConvert = mach_absolute_time()
            var block: String = NSString(data: dataBuffer, encoding: NSUTF8StringEncoding)
            
            endConvert = mach_absolute_time()
            totalConvertTime += (endConvert - startConvert)
            // tokenizing for lines
            startTokenizing = mach_absolute_time()
            var lines = block.componentsSeparatedByString("\n")
            endTokenizing = mach_absolute_time()
            totalTokenizingTime += (endTokenizing - startTokenizing)

            var lineCount = lines.count - 1
            
            for (var i = 0; i < lineCount - 1; i++)
            {
                // timing read operations
                startRead = mach_absolute_time()
                var line: String = lines [i]
                endRead = mach_absolute_time()
                totalReadTime += endRead - startRead
                numOfLines++;
                
                // convert NSString to NSData
                startConvert = mach_absolute_time()
                outData = line.dataUsingEncoding (NSUTF8StringEncoding)
                endConvert = mach_absolute_time()
                // println ("out data: \(outData)")
                totalConvertTime += (endConvert - startConvert)
                
                // timing write operation (seek and write)
                fileHandleOut.seekToFileOffset (writeOffset)
                // do not use writeTofile
                startWrite = mach_absolute_time()
                fileHandleOut.writeData(outData)
                endWrite = mach_absolute_time()
                writeOffset += outData!.length
                totalWriteTime += endWrite - startWrite
            }
            var lastLineSize = countElements(lines [lineCount])
            // subtract lastLineSize to discount partial line
            offset += bufferSize - lastLineSize
        } else {
            eof = true
        }
    } while (!eof);
    
    end = mach_absolute_time()
    let elapsed = (end - start) / 1000000
    
    // report throughput numbers
    println ("Total Time: \(elapsed) ms")
    println ("test data file size = \(inputFileSize) bytes")
    println ("Total number of lines: \(numOfLines)")
    println ("total tokenizing time =   \(totalTokenizingTime / 1000000) ms")
    println ("total convert time =   \(totalConvertTime / 1000000) ms")
    println ("total read time =   \(totalReadTime / 1000000) ms")
    if totalReadTime > 0 {
        let readThroughput = Double (inputFileSize) / Double (totalReadTime)
         println ("read throughput on this drive =  \(1000 * readThroughput) MB/second")
    }
        println ("total write time =   \(totalWriteTime / 1000000) ms")
    if totalWriteTime > 0 {
        let writeThroughput = Double (inputFileSize) / Double (totalWriteTime)
        println ("write throughput on this drive =  \(1000 * writeThroughput) MB/second")
    }

    // close file handles
    fileHandleIn.closeFile ()
    fileHandleOut.closeFile ()
    
}
func getLines (fileHandle: NSFileHandle, offset: UInt64, bufferSize: Int) -> [String]{
    // seek and read using a data buffer
    fileHandle.seekToFileOffset (offset)
    var dataBuffer: NSData = fileHandle.readDataOfLength(bufferSize)
    // convert NSData to String
    var block: String = NSString(data: dataBuffer, encoding: NSUTF8StringEncoding)
    // tokenizing for lines
    var tokens = block.componentsSeparatedByString("\n")
    
    return tokens
}
// Get current date/time, format is YYYY-MM-DD.HH:mm:ss GMT
func currentDateTime() -> NSDate {
    var now = NSDate ()
    //var current: NSDate = now.dateWithCalendarFormat ("%Y-%m-%d %H:%M:%S %z")
    var current: NSDate = now
    //NSTimeZone(PST)
    
    return current
}
// get current local time with ms
// Swift does not support setDateFormat yet
func getLocalTime () -> String
    {
        var currentDate = NSDate ()
        
        var dateFormatter = NSDateFormatter ()
        dateFormatter.dateStyle = .ShortStyle
        let localDateString: String = dateFormatter.stringFromDate (currentDate)
        
        var timeFormatter = NSDateFormatter ()
        timeFormatter.timeStyle = .FullStyle
        let localTimeString: String = timeFormatter.stringFromDate (currentDate)
        
        return localDateString + " " + localTimeString
}

func getStartTimeInSeconds () -> Int {
    // get current date, timezone and interval from GMT
    var  now = NSDate ()
    // local timezone
    var zone: NSTimeZone = NSTimeZone.systemTimeZone()
    var interval = zone.secondsFromGMT
    
    // return start time in seconds - used as a postfix for creating a new output file
    var startTime = Int(now.timeIntervalSince1970)  + interval
    println ("start time in seconds: \(startTime)")
    
    return startTime
}

func getFileNamePostFix () -> String{
    let fileNamePostFix = String (getStartTimeInSeconds())
    return fileNamePostFix;
}

println ("start time: \(getLocalTime ())")
let fileName = "/Users/henry/mydev/workspace/ios8/DiskCheck/ioTest1.txt"
let bufferSize = 50000
readWriteTest (fileName: fileName, bufferSize: bufferSize)
println ("end time: \(getLocalTime ())")


