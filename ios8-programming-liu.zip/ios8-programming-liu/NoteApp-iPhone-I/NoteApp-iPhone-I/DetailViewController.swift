//
//  DetailViewController.swift
//  NoteApp-iPhone-I
//
//  Created by Henry Liu on 9/4/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var textField: UITextField!
    //@IBOutlet var textField: UITextField?
    @IBOutlet weak var textView: UITextView!
    var noteItem: NoteItem?
    
    //@IBAction func saveButton(sender: AnyObject) {
    //}
    var detailItem: AnyObject? {
        didSet {
        println ("DVC: didSet +")
            // set noteItem here. don't set it else where
            if let detail: AnyObject = self.detailItem as? NoteItem {
                noteItem = detail as? NoteItem
            } else {
                println ("DVC: detail nil")
            }
            // no need to call configureView. viewDidLoad will call it anyway
            //self.configureView()
        println ("DVC: didSet -")
        }
    }

    func configureView() {
        println ("DVC: configureView +")
        if let tv = textField {
            self.textField.text = noteItem?.itemName as String!
            self.textView.text = noteItem?.content as String!
            println ("DVC: textField is \(self.textField.text)")
        } else {
            println ("textField is nil")
        }
        println ("DVC: configureView -")
    }

    override func viewDidLoad() {
        println ("DVC: viewDidLoad +")
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.configureView()
        println ("DVC: viewDidLoad -")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        println ("DVC: prepareForSegue + \(segue.identifier)")
        // do not use segue.identifier as it has no identifier
        if sender as? UIBarButtonItem != self.saveButton {
            return
        }
        
        if !textField.text.isEmpty {
            self.noteItem?.itemName = self.textField.text
            self.noteItem?.content = self.textView.text
        } else {
            println ("text field is empty")
        }
        println ("DVC: prepareForSegue -")
    }
}

