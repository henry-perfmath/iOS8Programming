//
//  main.swift
//  AdvancedSwift
//
//  Created by Henry Liu on 8/21/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//
import Foundation
/*
var savingsAccount = SavingsAccount (12345678)
println (savingsAccount.description)

savingsAccount.interestRate = 0.0125
savingsAccount.deposit (100.0)
println (savingsAccount.description)
*/
/*

let accounts = [SavingsAccount (12345670),
        CheckingAccount (12345671),
        SavingsAccount (12345672),
        CheckingAccount (12345673),
        SavingsAccount (12345674)]

var numOfSavingsAccount = 0
var numOfCheckingAccount = 0

for account in accounts {
    if account is SavingsAccount {
        ++numOfSavingsAccount
    } else if account is CheckingAccount {
        ++numOfCheckingAccount
    }
}

println ("number of savings account: \(numOfSavingsAccount)")
println ("number of checking account: \(numOfCheckingAccount)")
*/
/*
let accounts = [SavingsAccount (12345670),
    CheckingAccount (12345671),
    SavingsAccount (12345672),
    CheckingAccount (12345673),
    SavingsAccount (12345674)]

for account in accounts {
    if let savingsAccount = account as? SavingsAccount {
        savingsAccount.interestRate = 0.0125
        println ("savings account: \(savingsAccount.description)")
    } else if let checkingAccount = account as? CheckingAccount {
        checkingAccount.monthlyFee = 5.0
        println ("checking account: \(checkingAccount.description)")
    }
}
*/
/*

var anyThings = [Any]()

anyThings.append(0)
anyThings.append(0.0)
anyThings.append(999)
anyThings.append(3.1415926535897)
anyThings.append("Hello, Swift!")
anyThings.append((4.9, 5.0))
anyThings.append(CheckingAccount(123456781))
anyThings.append(SavingsAccount(123456780))

for thing in anyThings {
    switch thing {
        case 0 as Int:
            println("zero as an Int")
        case 0 as Double:
            println("zero as a Double")
        case let anInt as Int:
            println("an integer value of \(anInt)")
        case let aDouble as Double where aDouble > 0:
            println("a positive double value of \(aDouble)")
        case is Double:
            println("some other double value that I don't want to print")
        case let aString as String:
            println("a string value of \"\(aString)\"")
        case let (x, y) as (Double, Double):
            println("an (x, y) point at \(x), \(y)")
        case let checkingAccount as CheckingAccount:
            println("a checking account '\(checkingAccount.description)'")
        default:
            println("some thing else")
    }
}
*/
/*
let objects: [AnyObject] = [SavingsAccount (12345670),
    SavingsAccount (12345672),
    SavingsAccount (12345674)]

for anyObject in objects {
    let object = anyObject as SavingsAccount
    println ("\(object.description)")
}
*/
/*
let xAccount = XAccount (accountId: 123456780, balance: 0.0)
var superSavingsAccount = SuperSavingsAccount ()
superSavingsAccount.account = xAccount
println (superSavingsAccount.description)
*/
/*
var accountType = AccountType.PremiumChecking
//println (accountType)
switch accountType {
    case .Savings:
        println (" Is a savings account")
    case .SuperSavings:
    println (" Is a super savings account")
    case .FreeChecking:
    println (" Is a free checking account")
    case .PremiumChecking:
    println (" Is a premumium checking account")
}
*/

/*
var state = State.CA
println ("From toRaw method: CA is for \(state.toRaw ())")

// must use optional binding
if let possibleState = State.fromRaw("Washington") {
    println ("From fromRaw method: \(possibleState.toRaw())")
    switch possibleState {
    case .VA:
        println ("state = CA")
    case .WA:
        println ("state = WA")
    case .CA:
        println ("state = CA")
    }
} else {
    println ("State note defined")
}
*/
/*
var weekDay = WeekDays.Monday.toRaw()
println ("Monday's raw value from toRaw(): \(weekDay)")

if let possibleWeekDay = WeekDays.fromRaw(1) {
    println ("Reverse lookup with fromRaw for raw value of 1:")
    switch possibleWeekDay {
        case .Monday:
            println ("week day = Monday")
        case .Tuesday:
            println ("week day = Tuesday")
        case .Wednesday:
            println ("week day = Wednesday")
        case .Thursday:
        println ("week day = Thursday")
        case .Friday:
        println ("week day = Friday")
        case .Saturday:
        println ("week day = Saturday")
        case .Sunday:
        println ("week day = Sunday")
    }
} else {
    println ("weekDay note defined")
}

*/
/*
var accountID = AccountIDType.InNumber (123456780)

switch accountID {
    case .InNumber (let accountNumber):
        println ("account Id in Number: \(accountNumber)")
    case .InString (let accountId):
        println ("account Id in String: \(accountId)")
}

accountID = .InString ("FC-123456780")

switch accountID {
case .InNumber (let accountNumber):
    println ("account Id in Number: \(accountNumber)")
case .InString (let accountId):
    println ("account Id in String: \(accountId)")
}
*/
/*
var savingsAccount = SavingsAccount (12345678)
println (savingsAccount.description)

savingsAccount.interestRate = 0.01
savingsAccount.deposit (3650.0)
println (savingsAccount.description)

println ("today's interest: $\(savingsAccount.dailyInterest)")
*/

/*
var personalCheckingAccount = PersonalCheckingAccount(accountName: "Premium Checking", userName: "Henry")
println ("account name: \(personalCheckingAccount.accountName)")
println ("full name: \(personalCheckingAccount.fullName)")
*/
/*
var personalCheckingAccount = PersonalCheckingAccount(accountName: "Premium Checking", userName: "Henry")
println ("account name: \(personalCheckingAccount.accountName)")
println ("full name: \(personalCheckingAccount.fullName)")
println (personalCheckingAccount.welcome())

println (Int (2.5))
*/
/*
func getCurrentTime () -> String {
    let date = NSDate ()
    let formatter = NSDateFormatter ()
    formatter.timeStyle = .LongStyle
    var stringValue = formatter.stringFromDate (date)
    
    let timeSinceNow = date.timeIntervalSinceNow
    let timeSince1970 = date.timeIntervalSince1970
    
    println (timeSinceNow)
    println (timeSince1970)
    
    return stringValue
}

let time = getCurrentTime()
println (time)

let userDefaults = NSUserDefaults.standardUserDefaults()
let lastRefreshDate: AnyObject? = userDefaults.objectForKey("LastRefreshDate")
if let date = lastRefreshDate as? NSDate {
    println("\(date.timeIntervalSinceReferenceDate)")
}
*/
/*
let generator = LinearCongruentialGenerator()
println("first random number: \(generator.random())")
// output: 0.807428428836319
println("second random number: \(generator.random())")
// output: 0.0758740317612226
*/
let date = NSDate ()
println (date)

var d6 = Dice(sides: 6, generator: LinearCongruentialGenerator())
for _ in 1...5 {
    println("Random dice roll is \(d6.roll())")
}