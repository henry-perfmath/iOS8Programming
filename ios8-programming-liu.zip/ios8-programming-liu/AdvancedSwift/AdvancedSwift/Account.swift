//
//  Account.swift
//  AdvancedSwift
//
//  Created by Henry Liu on 8/21/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//
import Foundation

class Account {
    var accountId: Int?
    var balance: Double = 0.0
    var description: String {
            return "account id: \(accountId) with balance: \(balance)"
    }
    init (_ accountId: Int) {
        self.accountId = accountId
    }
    func deposit (amount: Double) {
    }
}

class SavingsAccount: Account {
    var interestRate: Double = 0.0
    override var description: String {
        return super.description + " and interest rate: \(interestRate)"
    }
    override func deposit (amount: Double) {
        balance += amount
    }
}

class CheckingAccount: Account {
    var monthlyFee: Double = 0.0
    override var description: String {
        return super.description + " and monthly fee: \(monthlyFee)"
    }
    override func deposit (amount: Double) {
        balance += amount
    }
}

struct XAccount {
    var accountId: Int?
    var balance: Double
    var description: String {
        return "account id: \(accountId) balance \(balance)"
    }
}

class SuperSavingsAccount {
    var account = XAccount (accountId: nil, balance: 0.0)
    var interestRate: Double = 0.0125
    var description: String {
        return "\(account.description) interestRate \(interestRate)"
    }
}

enum AccountType {
    case Savings
    case SuperSavings
    case FreeChecking
    case PremiumChecking
}

enum AccountIDType {
    case InNumber (Int)
    case InString (String)
}

enum WeekDays: Int {
    case Monday = 0, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
}

enum State: String {
    case VA = "Virginia"
    case WA = "Washington"
    case CA = "California"
}

extension SavingsAccount {
    var dailyInterest: Double {
        return balance * interestRate / 365.0
    }
}

protocol NamingAccount {
    var fullName: String {get}
}

/*
class PersonalCheckingAccount: NamingAccount {
    var userName: String?
    var accountName: String
    init(accountName: String, userName: String? = nil) {
        self.accountName = accountName
        self.userName = userName
    }
   
    var fullName: String {
        return (userName != nil ? userName! + "'s " : "") + accountName
    }
}
*/

protocol DailyGreeting {
    func welcome () ->  String
}
class PersonalCheckingAccount: NamingAccount,  DailyGreeting{
    var userName: String?
    var accountName: String
    init(accountName: String, userName: String? = nil) {
        self.accountName = accountName
        self.userName = userName
    }
    
    var fullName: String {
        return (userName != nil ? userName! + "'s " : "") + accountName
    }
    
    func welcome () -> String {
        return (userName != nil ? userName!: "") + ", welcome back!"
    }
}

protocol RandomNumberGenerator {
    func random() -> Double
}

class LinearCongruentialGenerator: RandomNumberGenerator {
    var lastRandom = 242.0
    let m = 2139968.0
    let a = 23877.0
    let c = 229573.0
    func currentTimeInSeconds() -> Double {
        let now = NSDate ()
        return Double (now.timeIntervalSince1970)
    }
    func random() -> Double {
        lastRandom = ((lastRandom * a + c) % m)
        return lastRandom / m
    }
}

class Dice {
    let sides: Int
    let generator: RandomNumberGenerator
    init(sides: Int, generator: RandomNumberGenerator) {
        self.sides = sides
        self.generator = generator
    }
    func roll() -> Int {
        return Int(generator.random() * Double(sides)) + 1
    }
}

protocol DiceGame {
    var dice: Dice { get }
    func play()
}
protocol DiceGameDelegate {
    func gameDidStart(game: DiceGame)
    func game(game: DiceGame, didStartNewTurnWithDiceRoll diceRoll: Int)
    func gameDidEnd(game: DiceGame)
}
class User {
    var numOfAccesses = 0
}
protocol OnlineAccess {
    var user: Account { get }
    func access ()
}
protocol OnlineAccessDelegate {
    func userDidLogin(account: Account)
    func user(account: Account, didStartNewTurnWithDiceRoll diceRoll: Int)
    func userDidLogout(account: Account)
}
