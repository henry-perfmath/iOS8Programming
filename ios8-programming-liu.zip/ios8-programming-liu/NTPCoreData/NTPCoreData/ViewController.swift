//
//  ViewController.swift
//  NTPCoreData
//
//  Created by Henry Liu on 8/27/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import UIKit
import CoreData

@objc (NoteItem)
class NoteItem: NSManagedObject {
    @NSManaged var itemName: String
}

class ViewController: UIViewController {

    @IBOutlet weak var textView: UITextView!
    @IBAction func saveData(sender: AnyObject) {
        println ("saving note using Core Data for \(textView.text)")
        let  appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        let context: NSManagedObjectContext = appDelegate.managedObjectContext!
        let noteEntity = NSEntityDescription.entityForName("Notes", inManagedObjectContext: context)
        
        // insert newNote into context
        var newNote = NoteItem (entity: noteEntity!, insertIntoManagedObjectContext: context)
        
        // bad -  crashes even w/o newNote.itemName = textView.text
        // var newNote = NSEntityDescription.insertNewObjectForEntityForName("MyNotes",inManagedObjectContext: context) as NoteItem
        
        //set note name (don't do newNote.itemName = textView.text - crashes)
        newNote.setValue(textView.text, forKey: "note")
        var error: NSError?
        context.save(&error)
        println ("note \"\(textView.text)\" saved")
    }
    @IBAction func findNote(sender: AnyObject) {
        println ("finding note using Core Data for \(textView.text)")
        let  appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        let context: NSManagedObjectContext = appDelegate.managedObjectContext!
        let noteEntity = NSEntityDescription.entityForName("Notes", inManagedObjectContext: context)
        
        let searchString = textView.text
        // must include double quote escape
        var request: NSFetchRequest  = NSFetchRequest (entityName: "Notes")
        request.predicate = NSPredicate (format: "note == \"\(searchString)\"")
        
        var error: NSError?
        var objects = context.executeFetchRequest (request, error:&error)
        
        if objects?.count == 0 {
            println ("No matches for \"\(searchString)\"")
        } else {
            println ("found: \(objects?.count) items with search string \"\(searchString)\"")
            for foundItem: NSManagedObject in objects as [NSManagedObject] {
                var itemName = foundItem.valueForKey("note") as String
                println ("found: \(itemName) of \(objects?.count)")
            }
            
            //            var matches:  NSManagedObject = objects [0] as NSManagedObject
            //            var text = matches.valueForKey("note") as String
            //            println ("matches found \(text)")
        }
        
    
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

