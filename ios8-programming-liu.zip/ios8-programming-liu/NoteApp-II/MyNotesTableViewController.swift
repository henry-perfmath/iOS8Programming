//
//  MyNotesTableViewController.swift
//  NoteApp
//
//  Created by Henry Liu on 8/25/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation
import UIKit

class MyNotesTableViewController: UITableViewController, UITableViewDelegate, UITableViewDataSource {
    var noteItems = [AnyObject] ()
    var _dataFilePath = "/noteapp2_data.archive"

    @IBAction func unwindToList (segue: UIStoryboardSegue) {
        var source: AddNewNoteItemViewController = segue.sourceViewController as AddNewNoteItemViewController
        if let item = source.noteItem as NoteItem! {
            self.noteItems.append(item)
            self.tableView.reloadData()
            saveData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        loadInitialData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    // not needed anymore in iOS 8
    func numberOfRowsInSelection (tableView: UITableView) -> Int {
       return noteItems.count
    }
    func saveData () {
        var itemArray = [AnyObject] ()
    
        for item: NoteItem in noteItems as [NoteItem] {
            itemArray.append(item.itemName)
        }
        NSKeyedArchiver.archiveRootObject(itemArray, toFile: _dataFilePath)
        println ("completed saving data to: \(_dataFilePath)")
    }
        
    func loadInitialData () {
        var docsDir: String = ""
        var dirPths = [AnyObject]()
        
        dirPths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        docsDir = dirPths [0] as String
        //docsDir = "/Users/henry/mydev" 
        // have to overwrite as the default Documents folder does not work
        _dataFilePath = docsDir + _dataFilePath
        
        var fileMgr = NSFileManager.defaultManager()
        if fileMgr.fileExistsAtPath (_dataFilePath)
        {
            println ("Load data from file: \(_dataFilePath)")
            var dataArray = [String]()
            
            dataArray = NSKeyedUnarchiver.unarchiveObjectWithFile (_dataFilePath) as [String]
            println ("number of items to load: \(dataArray.count)")
            
            for itemName:String in dataArray as [String] {
                var item: NoteItem = NoteItem (name: itemName)
                noteItems.append (item)
                println ("added item: \(item.itemName)")
            }
            
        } else {
            println ("File does not exist: \(_dataFilePath)")
        }
    }
    override func tableView (tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let listPropertyCell: String = "ListPrototypeCell"
        var cell: UITableViewCell = self.tableView.dequeueReusableCellWithIdentifier(listPropertyCell, forIndexPath: indexPath) as UITableViewCell
        var noteItem: NoteItem = noteItems [indexPath.row] as NoteItem
        cell.textLabel?.text = noteItem.itemName
        
        if noteItem.completed {
            cell.accessoryType = UITableViewCellAccessoryType.Checkmark
            noteItem.setCompletionDate(onDate: NSDate ())
        } else {
            cell.accessoryType = UITableViewCellAccessoryType.None
        }
        return cell
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return self.noteItems.count
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        println ("didSelectRowAtIndexPath: \(indexPath.row)")
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        let tappedItem: NoteItem = noteItems [indexPath.row] as NoteItem
        tappedItem.completed = !tappedItem.completed
        //tableView.reloadData()
        tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
        //reloadInputViews()
    }
}